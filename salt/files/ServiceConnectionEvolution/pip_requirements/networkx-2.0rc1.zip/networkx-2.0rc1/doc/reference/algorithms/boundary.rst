********
Boundary
********

.. automodule:: networkx.algorithms.boundary
.. autosummary::
   :toctree: generated/

   edge_boundary
   node_boundary

