# ServiceConnectEvolution
=======================
收集service进程,监听,socket交互,存储入数据库；并生成service交互图.称之为进化.

usage:
	rename config.ini.for_git to config.ini


